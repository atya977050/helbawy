
const socket = io();
let localStream, remoteStream, peerConnection;
const servers = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
async function init() {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
}
init();

 peerConnection.ontrack = (e) => { remoteVideo.srcObject = e.streams[0]; };